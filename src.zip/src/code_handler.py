# -*- coding: utf-8 -*-
"""
Created on Mon Jun 16 13:50:23 2025

@author: cmf6
"""
import re
import customtkinter as ctk

class Code_Handler():
    def __init__(self, port_manager):
        self.code_dictionary = {
            "turtle.forward": "F",  #will need more
            "turtle.right": "T",
            "turtle.left": "T-",
            "print":"=",
            "turtle.up": "U",
            "turtle.down": "D"
            }
        self.port_manager = port_manager
        
    def handle_code(self, code_input, turtle, text_output):
        if len(code_input) >1:
            #text_output.configure(text="Compiling code")
            text_output.configure(state="normal")
            text_output.delete(1.0, ctk.END)
            text_output.insert(ctk.END, text="Compiling code")
            text_output.configure(state="disabled")
        try:
            #test if the code compiles
            turtle.test_code(code_input, text_output)

            if not text_output.get(1.0, 1.14) == "Compiling code":
                return
            #split code into  lines
            code_lines = code_input.splitlines()
            for_loop =0
            processed_lines = []
            preprocessing_lines = []
            for line in code_lines:
                tabs = ""
                for_loop = line.count("\t")
                for i in range (for_loop):
                    tabs+="\t"
                #if line not just spaces
                if not line.isspace() and not line=="":
                    print("b",line)
                    if line.strip()[0]=="t" or line.strip()[0]=="p":
                        line_processed = line.replace("\"", "\\\"")
                        preprocessing_lines.append(tabs+"processed_lines.append(\""+line_processed.strip()+"\")") 

                    elif line.strip()[0]=="f":
                        for_loop+=1
                        preprocessing_lines.append(line)
                    else:
                        preprocessing_lines.append(line)
            #join the list together with newlines between each
            res = '\n'.join(preprocessing_lines)
        
            #run to get the list of instructions
            exec(res)
            
            turtlebot_lines = self.translate_to_bot(processed_lines)
            current_line = 0
            turtle.run_code("turtle.up()", text_output)
            #run list on simulation
            for line in processed_lines:
                if turtle.get_paused():
                    break
                #display on output
                text_output.configure(state="normal")
                text_output.insert(ctk.END, text="\n"+line)
                text_output.configure(state="disabled")
                text_output.see(ctk.END)
                
                # Run code on the simulator
                turtle.run_code(line, text_output)
                if not turtlebot_lines[current_line][0] == "":
                    #If a turn is done, handle the three commands (pen up, turn, pen down)
                    if "T" in turtlebot_lines[current_line][1]:
                        for mini_line in turtlebot_lines[current_line]:
                            self.port_manager.send_command(mini_line)
                    else:
                        self.port_manager.send_command(turtlebot_lines[current_line])
                current_line+=1
            # Lift pen and turn motors off at the                current_line+=1
            #lift pen and turn motors off at end
            self.port_manager.send_command("U"+str(self.port_manager.up))
            self.port_manager.send_command("o")
            if not turtle.get_paused():
                #display on output
                text_output.configure(state="normal")
                text_output.insert(ctk.END, text="\nCompleted Successfully")
                text_output.configure(state="disabled")
                text_output.see(ctk.END)
        except Exception as e:
            print("E:",e)
            pass
        
    def translate_to_bot(self, processed_lines):
        bot_lines = []
        pen_down=False
        for line in processed_lines:
            #split line by brackets
            split_line = re.split(r'[()\"]+', line)
            print(split_line)
            if split_line[0] in self.code_dictionary:
                bot_equivalent = self.code_dictionary.get(split_line[0])
                if bot_equivalent == "U":
                    pen_down=False
                    bot_lines.append(bot_equivalent+str(self.port_manager.up))
                elif bot_equivalent == "D":
                    pen_down=True
                    bot_lines.append(bot_equivalent+str(self.port_manager.down))
                elif "T" in bot_equivalent:
                    new_line=bot_equivalent+split_line[1]
                    if pen_down:
                        lines = ["U"+str(self.port_manager.up), new_line, "D"+str(self.port_manager.down)]
                        bot_lines.append(lines)
                    else:
                        bot_lines.append(new_line)
                else:
                    new_line=bot_equivalent+split_line[1]
                    bot_lines.append(new_line)
            else:
                bot_lines.append("")
            print(bot_lines)
        return bot_lines